        <footer class="p-4 h-10 bg-white dark:bg-slate-800 rounded-xl shadow-md flex items-center justify-center" id="footer">
                <i class="text-gray-500 fa-solid fa-copyright"></i>
                <p class="mx-2 text-md text-gray-500">2022 - Ryan Abi</p>
        </footer>
</section>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<script src="https://unpkg.com/flowbite@1.5.4/dist/flowbite.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
</body>

</html>